import { requireAdmin } from '../../../lib/auth.js'
import { logEvent } from '../../../lib/logger.js'

const VALID_TYPES = ['audio', 'video', 'case', 'reflect']

export async function onRequestGet({ env, request }) {
  if (!await requireAdmin(request, env)) return new Response('Forbidden', { status: 403 })

  const [{ results: items }, { results: weekRows }] = await Promise.all([
    env.DB.prepare('SELECT id, type, title, meta, r2_key, abstract, body, prompt FROM content_items ORDER BY type, title LIMIT 500').all(),
    env.DB.prepare('SELECT content_id, week_id, position, is_default FROM week_content ORDER BY week_id, position').all(),
  ])

  const weeksByItem = {}
  for (const w of weekRows) {
    if (!weeksByItem[w.content_id]) weeksByItem[w.content_id] = []
    weeksByItem[w.content_id].push({ week_id: w.week_id, position: w.position, is_default: w.is_default ?? 0 })
  }

  return Response.json(items.map(item => ({ ...item, weeks: weeksByItem[item.id] || [] })))
}

export async function onRequestPost({ env, request }) {
  const caller = await requireAdmin(request, env)
  if (!caller) return new Response('Forbidden', { status: 403 })

  const { id, type, title, meta, r2_key, abstract, body, prompt, weeks } = await request.json()

  if (!id?.trim() || !title?.trim()) return new Response('id and title are required', { status: 400 })
  if (!VALID_TYPES.includes(type))   return new Response('Invalid type', { status: 400 })

  try {
    await env.DB.prepare(
      'INSERT INTO content_items (id, type, title, meta, r2_key, abstract, body, prompt) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(id.trim(), type, title.trim(), meta || null, r2_key || null, abstract || null, body || null, prompt || null).run()
  } catch (e) {
    if (e.message?.includes('UNIQUE')) return new Response('ID already in use', { status: 409 })
    throw e
  }

  const assignedWeeks = []
  if (weeks?.length) {
    for (const w of weeks) {
      const isDefault = w.is_default ? 1 : 0
      if (isDefault) {
        await env.DB.prepare('UPDATE week_content SET is_default = 0 WHERE week_id = ?').bind(w.week_id).run()
      }
      await env.DB.prepare('INSERT INTO week_content (week_id, content_id, position, is_default) VALUES (?, ?, ?, ?)')
        .bind(w.week_id, id.trim(), w.position ?? 0, isDefault).run()
      assignedWeeks.push({ ...w, is_default: isDefault })
    }
  }

  const item = await env.DB.prepare('SELECT * FROM content_items WHERE id = ?').bind(id.trim()).first()

  await logEvent(env, {
    event:   'content.created',
    tag:     'innhold',
    actorId: caller.sub,
    meta:    { content_id: item.id, title: item.title, type: item.type },
  })

  return Response.json({ ...item, weeks: assignedWeeks }, { status: 201 })
}
